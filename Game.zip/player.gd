extends CharacterBody3D

signal died

const TouchScript = preload("res://touch.gd")
const WALK_SPEED := 4.5
const SPRINT_SPEED := 7.2
const ROLL_SPEED := 9.5
const GRAVITY := 24.0

var max_health := 100.0
var health := 100.0
var max_stamina := 100.0
var stamina := 100.0
var flasks := 3

var state := "idle"  # idle, attack, roll, hit, heal, dead
var state_time := 0.0
var attack_kind := "light"
var hit_done := false
var invuln := false
var roll_dir := Vector3.FORWARD
var stamina_delay := 0.0
var locked_on = null

var model: Node3D
var rig: Node3D
var weapon_pivot: Node3D
var cam_pivot: Node3D
var cam: Camera3D
var cam_yaw := 0.0
var cam_pitch := -0.35
var body_mat: StandardMaterial3D


func _ready() -> void:
	add_to_group("player")
	var shape := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	shape.shape = cap
	shape.position.y = 0.9
	add_child(shape)

	model = Node3D.new()
	add_child(model)
	rig = Node3D.new()
	rig.position.y = 0.9
	model.add_child(rig)

	# PLACEHOLDER BODY - replace with a realistic character model later.
	body_mat = StandardMaterial3D.new()
	body_mat.albedo_color = Color(0.55, 0.5, 0.45)
	body_mat.roughness = 0.8
	body_mat.emission_enabled = true
	body_mat.emission = Color(1, 0, 0)
	body_mat.emission_energy_multiplier = 0.0
	var body := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.35
	cm.height = 1.7
	body.mesh = cm
	body.material_override = body_mat
	rig.add_child(body)

	weapon_pivot = Node3D.new()
	weapon_pivot.position = Vector3(0.45, 0.2, -0.2)
	rig.add_child(weapon_pivot)
	var blade := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.07, 0.05, 1.3)
	blade.mesh = bm
	blade.position = Vector3(0, 0, -0.7)
	var blade_mat := StandardMaterial3D.new()
	blade_mat.albedo_color = Color(0.75, 0.78, 0.82)
	blade_mat.metallic = 0.9
	blade_mat.roughness = 0.3
	blade.material_override = blade_mat
	weapon_pivot.add_child(blade)
	weapon_pivot.rotation.x = 0.6

	cam_pivot = Node3D.new()
	cam_pivot.top_level = true
	add_child(cam_pivot)
	cam = Camera3D.new()
	cam.position = Vector3(0, 0.4, 5.0)
	cam.fov = 70.0
	cam_pivot.add_child(cam)
	cam.current = true
	cam_pivot.global_position = global_position + Vector3(0, 1.5, 0)
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0)


func _set_state(s: String) -> void:
	state = s
	state_time = 0.0
	hit_done = false


func _facing() -> Vector3:
	return Vector3(-sin(model.rotation.y), 0.0, -cos(model.rotation.y))


func _face(dir: Vector3, weight: float) -> void:
	model.rotation.y = lerp_angle(model.rotation.y, atan2(-dir.x, -dir.z), clampf(weight, 0.0, 1.0))


func rumble(weak: float, strong: float, duration: float) -> void:
	Input.start_joy_vibration(0, weak, strong, duration)


func _physics_process(delta: float) -> void:
	if state == "dead":
		velocity.x = 0.0
		velocity.z = 0.0
		velocity.y -= GRAVITY * delta
		move_and_slide()
		return

	state_time += delta
	_handle_lock_on()
	if stamina_delay > 0.0:
		stamina_delay -= delta
	elif state == "idle" or state == "heal":
		stamina += 32.0 * delta
	stamina = clampf(stamina, 0.0, max_stamina)

	var move := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var wish: Vector3 = Basis(Vector3.UP, cam_yaw) * Vector3(move.x, 0.0, move.y)

	match state:
		"idle":
			_state_idle(delta, wish)
		"attack":
			_state_attack()
		"roll":
			_state_roll()
		"hit":
			velocity.x = 0.0
			velocity.z = 0.0
			if state_time >= 0.4:
				_set_state("idle")
		"heal":
			_state_heal()

	if is_on_floor():
		velocity.y = -0.1
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()
	_update_camera(delta)


func _state_idle(delta: float, wish: Vector3) -> void:
	var speed := WALK_SPEED
	if Input.is_action_pressed("sprint") and wish.length() > 0.1 and stamina > 1.0:
		speed = SPRINT_SPEED
		stamina -= 14.0 * delta
		stamina_delay = 0.8
	velocity.x = wish.x * speed
	velocity.z = wish.z * speed

	if locked_on != null and is_instance_valid(locked_on):
		var to: Vector3 = locked_on.global_position - global_position
		to.y = 0.0
		if to.length() > 0.1:
			_face(to.normalized(), delta * 10.0)
	elif wish.length() > 0.1:
		_face(wish.normalized(), delta * 12.0)

	if Input.is_action_just_pressed("dodge") and stamina >= 20.0:
		stamina -= 20.0
		stamina_delay = 0.7
		roll_dir = wish.normalized() if wish.length() > 0.1 else _facing()
		_set_state("roll")
	elif Input.is_action_just_pressed("attack_heavy") and stamina >= 25.0:
		stamina -= 25.0
		stamina_delay = 0.9
		attack_kind = "heavy"
		_set_state("attack")
	elif Input.is_action_just_pressed("attack_light") and stamina >= 12.0:
		stamina -= 12.0
		stamina_delay = 0.7
		attack_kind = "light"
		_set_state("attack")
	elif Input.is_action_just_pressed("heal") and flasks > 0 and health < max_health:
		_set_state("heal")


func _state_attack() -> void:
	var light := attack_kind == "light"
	var dur := 0.55 if light else 1.0
	var hit_t := 0.28 if light else 0.55
	var raise_end := hit_t - 0.12
	var swing_end := hit_t + 0.13
	if state_time < raise_end:
		weapon_pivot.rotation.x = lerpf(0.6, 1.8, state_time / raise_end)
	elif state_time < swing_end:
		weapon_pivot.rotation.x = lerpf(1.8, -1.0, clampf((state_time - raise_end) / 0.25, 0.0, 1.0))
	else:
		weapon_pivot.rotation.x = lerpf(-1.0, 0.6, clampf((state_time - swing_end) / (dur - swing_end), 0.0, 1.0))
	var f := _facing()
	var lunge := 2.5 if state_time < hit_t else 0.0
	velocity.x = f.x * lunge
	velocity.z = f.z * lunge
	if not hit_done and state_time >= hit_t:
		hit_done = true
		_deal_damage(light)
	if state_time >= dur:
		weapon_pivot.rotation.x = 0.6
		_set_state("idle")


func _deal_damage(light: bool) -> void:
	var reach := 3.4 if light else 3.8
	var dmg := 18.0 if light else 42.0
	var f := _facing()
	var landed := false
	for e in get_tree().get_nodes_in_group("enemies"):
		var to: Vector3 = e.global_position - global_position
		to.y = 0.0
		if to.length() < reach and f.dot(to.normalized()) > 0.1:
			e.take_damage(dmg, global_position)
			landed = true
	if landed:
		rumble(0.3, 0.6, 0.15)


func _state_roll() -> void:
	var t := state_time / 0.5
	invuln = state_time > 0.04 and state_time < 0.36
	var spd := ROLL_SPEED * (1.2 - 0.6 * t)
	velocity.x = roll_dir.x * spd
	velocity.z = roll_dir.z * spd
	model.rotation.y = atan2(-roll_dir.x, -roll_dir.z)
	rig.rotation.x = -t * TAU
	if state_time >= 0.5:
		rig.rotation.x = 0.0
		invuln = false
		_set_state("idle")


func _state_heal() -> void:
	velocity.x = 0.0
	velocity.z = 0.0
	if not hit_done and state_time >= 0.5:
		hit_done = true
		health = minf(max_health, health + 50.0)
		flasks -= 1
	if state_time >= 0.9:
		_set_state("idle")


func _handle_lock_on() -> void:
	if locked_on != null and (not is_instance_valid(locked_on) or locked_on.state == "dead"):
		locked_on = null
	if Input.is_action_just_pressed("lock_on"):
		if locked_on != null:
			locked_on = null
		else:
			var best = null
			var best_d := 22.0
			for e in get_tree().get_nodes_in_group("enemies"):
				var d := global_position.distance_to(e.global_position)
				if d < best_d:
					best = e
					best_d = d
			locked_on = best


func _update_camera(delta: float) -> void:
	var look := Input.get_vector("look_left", "look_right", "look_up", "look_down")
	var touch_look: Vector2 = TouchScript.look_delta
	TouchScript.look_delta = Vector2.ZERO
	if locked_on != null and is_instance_valid(locked_on):
		var to: Vector3 = locked_on.global_position - global_position
		cam_yaw = lerp_angle(cam_yaw, atan2(-to.x, -to.z), clampf(6.0 * delta, 0.0, 1.0))
		cam_pitch = lerpf(cam_pitch, -0.3, clampf(4.0 * delta, 0.0, 1.0))
	else:
		cam_yaw -= look.x * 2.8 * delta + touch_look.x * 0.005
		cam_pitch = clampf(cam_pitch - look.y * 2.0 * delta - touch_look.y * 0.004, -1.2, 0.35)
	cam_pivot.global_position = global_position + Vector3(0, 1.5, 0)
	cam_pivot.rotation = Vector3(cam_pitch, cam_yaw, 0)


func take_damage(amount: float, _from_pos: Vector3) -> void:
	if invuln or state == "dead":
		return
	health -= amount
	rumble(0.6, 0.8, 0.25)
	Input.vibrate_handheld(80)
	var tw := create_tween()
	tw.tween_property(body_mat, "emission_energy_multiplier", 0.0, 0.3).from(2.0)
	weapon_pivot.rotation.x = 0.6
	rig.rotation.x = 0.0
	if health <= 0.0:
		health = 0.0
		state = "dead"
		locked_on = null
		create_tween().tween_property(rig, "rotation:x", -PI / 2.0, 0.6)
		died.emit()
	else:
		_set_state("hit")
