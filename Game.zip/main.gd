extends Node3D

const PlayerScript = preload("res://player.gd")
const BossScript = preload("res://boss.gd")
const HudScript = preload("res://hud.gd")
const TouchScript = preload("res://touch.gd")

var player
var boss
var hud


func _ready() -> void:
	_setup_input()
	_build_world()
	player = PlayerScript.new()
	player.position = Vector3(0, 0.1, 14)
	add_child(player)
	boss = BossScript.new()
	boss.position = Vector3(0, 0.1, -8)
	add_child(boss)
	hud = HudScript.new()
	add_child(hud)
	hud.bind(player, boss)
	hud.add_child(TouchScript.new())
	player.died.connect(_on_player_died)
	boss.died.connect(_on_boss_died)
	boss.enraged.connect(func(): hud.show_message("THE WARDEN ENRAGES", Color(0.9, 0.25, 0.1), 2.5))
	hud.show_message("Defeat the Ashen Warden", Color(0.9, 0.85, 0.7), 3.0)


func _on_player_died() -> void:
	hud.show_message("YOU DIED", Color(0.7, 0.05, 0.05), 4.0)
	await get_tree().create_timer(4.0).timeout
	get_tree().reload_current_scene()


func _on_boss_died() -> void:
	hud.show_message("WARDEN FELLED", Color(0.9, 0.75, 0.3), 5.0)
	await get_tree().create_timer(5.0).timeout
	get_tree().reload_current_scene()


# ---------- Input (gamepad first, keyboard for testing) ----------
func _add(action: String) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action, 0.2)


func _key(action: String, keycode: Key) -> void:
	_add(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)


func _btn(action: String, button: JoyButton) -> void:
	_add(action)
	var ev := InputEventJoypadButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)


func _axis(action: String, axis: JoyAxis, value: float) -> void:
	_add(action)
	var ev := InputEventJoypadMotion.new()
	ev.axis = axis
	ev.axis_value = value
	InputMap.action_add_event(action, ev)


func _setup_input() -> void:
	_key("move_forward", KEY_W)
	_key("move_back", KEY_S)
	_key("move_left", KEY_A)
	_key("move_right", KEY_D)
	_axis("move_forward", JOY_AXIS_LEFT_Y, -1.0)
	_axis("move_back", JOY_AXIS_LEFT_Y, 1.0)
	_axis("move_left", JOY_AXIS_LEFT_X, -1.0)
	_axis("move_right", JOY_AXIS_LEFT_X, 1.0)
	_key("look_up", KEY_UP)
	_key("look_down", KEY_DOWN)
	_key("look_left", KEY_LEFT)
	_key("look_right", KEY_RIGHT)
	_axis("look_up", JOY_AXIS_RIGHT_Y, -1.0)
	_axis("look_down", JOY_AXIS_RIGHT_Y, 1.0)
	_axis("look_left", JOY_AXIS_RIGHT_X, -1.0)
	_axis("look_right", JOY_AXIS_RIGHT_X, 1.0)
	_key("attack_light", KEY_J)
	_btn("attack_light", JOY_BUTTON_X)
	_btn("attack_light", JOY_BUTTON_RIGHT_SHOULDER)
	_key("attack_heavy", KEY_K)
	_btn("attack_heavy", JOY_BUTTON_Y)
	_key("dodge", KEY_SPACE)
	_btn("dodge", JOY_BUTTON_B)
	_key("heal", KEY_E)
	_btn("heal", JOY_BUTTON_A)
	_key("lock_on", KEY_Q)
	_btn("lock_on", JOY_BUTTON_RIGHT_STICK)
	_key("sprint", KEY_SHIFT)
	_btn("sprint", JOY_BUTTON_LEFT_STICK)


# ---------- World ----------
func _box(size: Vector3, pos: Vector3, color: Color, rot_y := 0.0) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation.y = rot_y
	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mesh.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.95
	mesh.material_override = mat
	body.add_child(mesh)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)
	add_child(body)
	return body


func _torch(pos: Vector3) -> void:
	var light := OmniLight3D.new()
	light.position = pos
	light.light_color = Color(1.0, 0.6, 0.3)
	light.light_energy = 2.5
	light.omni_range = 16.0
	add_child(light)
	var flame := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.22
	sm.height = 0.44
	flame.mesh = sm
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(1.0, 0.55, 0.15)
	fm.emission_enabled = true
	fm.emission = Color(1.0, 0.5, 0.1)
	fm.emission_energy_multiplier = 3.0
	flame.material_override = fm
	flame.position = pos
	add_child(flame)


func _build_world() -> void:
	var env := Environment.new()
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.04, 0.05, 0.1)
	sky_mat.sky_horizon_color = Color(0.18, 0.15, 0.2)
	sky_mat.ground_horizon_color = Color(0.12, 0.1, 0.12)
	sky_mat.ground_bottom_color = Color(0.03, 0.03, 0.04)
	sky.sky_material = sky_mat
	env.sky = sky
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.6
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.15, 0.14, 0.18)
	env.fog_density = 0.015
	env.glow_enabled = true
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.light_color = Color(0.6, 0.7, 1.0)
	sun.light_energy = 0.9
	sun.rotation_degrees = Vector3(-55, 35, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)

	_box(Vector3(64, 1, 64), Vector3(0, -0.5, 0), Color(0.16, 0.15, 0.15))
	var count := 24
	for i in count:
		var a := TAU * i / count
		_box(Vector3(3, 10, 3), Vector3(cos(a) * 26.0, 5, sin(a) * 26.0), Color(0.22, 0.21, 0.22))
		var wa := a + TAU / (count * 2)
		_box(Vector3(7.4, 7, 1.5), Vector3(cos(wa) * 26.0, 3.5, sin(wa) * 26.0), Color(0.19, 0.18, 0.19), -wa - PI / 2.0)
	for i in 6:
		var a2 := TAU * i / 6.0 + 0.3
		var p := Vector3(cos(a2) * 12.0, 3, sin(a2) * 12.0)
		_box(Vector3(2, 6, 2), p, Color(0.24, 0.23, 0.24))
		_torch(p + Vector3(0, 3.6, 0))
