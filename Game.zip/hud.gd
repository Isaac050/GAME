extends CanvasLayer

var player
var boss
var health_fill: ColorRect
var stamina_fill: ColorRect
var boss_bg: ColorRect
var boss_fill: ColorRect
var boss_label: Label
var flask_label: Label
var msg: Label
var msg_id := 0


func _ready() -> void:
	layer = 10
	_make_bar(Vector2(20, 20), Vector2(300, 16), Color(0.6, 0.05, 0.05))
	health_fill = _last_fill
	_make_bar(Vector2(20, 42), Vector2(220, 10), Color(0.2, 0.65, 0.25))
	stamina_fill = _last_fill
	flask_label = _label(Vector2(20, 58), 18)

	boss_bg = ColorRect.new()
	boss_bg.color = Color(0, 0, 0, 0.6)
	add_child(boss_bg)
	boss_fill = ColorRect.new()
	boss_fill.color = Color(0.75, 0.1, 0.1)
	add_child(boss_fill)
	boss_label = _label(Vector2.ZERO, 20)
	boss_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	msg = Label.new()
	msg.set_anchors_preset(Control.PRESET_FULL_RECT)
	msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	msg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	msg.add_theme_font_size_override("font_size", 56)
	msg.add_theme_constant_override("outline_size", 8)
	msg.add_theme_color_override("font_outline_color", Color.BLACK)
	msg.visible = false
	add_child(msg)


var _last_fill: ColorRect


func _make_bar(pos: Vector2, size: Vector2, color: Color) -> void:
	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, 0.6)
	bg.position = pos - Vector2(2, 2)
	bg.size = size + Vector2(4, 4)
	add_child(bg)
	var fill := ColorRect.new()
	fill.color = color
	fill.position = pos
	fill.size = size
	add_child(fill)
	_last_fill = fill


func _label(pos: Vector2, font_size: int) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_constant_override("outline_size", 4)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	return l


func bind(p, b) -> void:
	player = p
	boss = b


func _process(_delta: float) -> void:
	if player != null:
		health_fill.size.x = 300.0 * player.health / player.max_health
		stamina_fill.size.x = 220.0 * player.stamina / player.max_stamina
		flask_label.text = "Flasks: %d" % player.flasks
	if boss != null:
		var vp := get_viewport().get_visible_rect().size
		var bw := minf(640.0, vp.x * 0.6)
		var bx := (vp.x - bw) / 2.0
		var by := vp.y - 60.0
		boss_bg.position = Vector2(bx - 2, by - 2)
		boss_bg.size = Vector2(bw + 4, 18)
		boss_fill.position = Vector2(bx, by)
		boss_fill.size = Vector2(bw * boss.health / boss.max_health, 14)
		boss_label.position = Vector2(bx, by - 30)
		boss_label.size.x = bw
		boss_label.text = boss.boss_name
		var bar_on: bool = boss.state != "dead"
		boss_bg.visible = bar_on
		boss_fill.visible = bar_on
		boss_label.visible = bar_on


func show_message(text: String, color: Color, duration: float) -> void:
	msg_id += 1
	var my_id := msg_id
	msg.text = text
	msg.add_theme_color_override("font_color", color)
	msg.visible = true
	await get_tree().create_timer(duration).timeout
	if my_id == msg_id:
		msg.visible = false
