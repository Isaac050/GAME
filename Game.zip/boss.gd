extends CharacterBody3D

signal died
signal enraged

const GRAVITY := 24.0

var max_health := 500.0
var health := 500.0
var boss_name := "THE ASHEN WARDEN"
var state := "chase"  # chase, windup, strike, recover, dead
var state_time := 0.0
var attack := ""
var windup := 0.7
var strike := 0.25
var recover := 0.8
var cooldown := 1.5
var hit_done := false
var is_enraged := false
var speed := 3.4
var hurt_t := 0.0

var player: Node3D
var model: Node3D
var rig: Node3D
var club_pivot: Node3D
var mat: StandardMaterial3D


func _ready() -> void:
	add_to_group("enemies")
	var shape := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.9
	cap.height = 2.8
	shape.shape = cap
	shape.position.y = 1.4
	add_child(shape)

	model = Node3D.new()
	add_child(model)
	rig = Node3D.new()
	rig.position.y = 1.4
	model.add_child(rig)

	# PLACEHOLDER BODY - replace with a realistic boss model later.
	mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.25, 0.22, 0.22)
	mat.roughness = 0.9
	mat.emission_enabled = true
	mat.emission = Color(1, 0.15, 0.05)
	mat.emission_energy_multiplier = 0.0
	var body := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.8
	cm.height = 2.8
	body.mesh = cm
	body.material_override = mat
	rig.add_child(body)
	var head := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.45
	sm.height = 0.9
	head.mesh = sm
	head.material_override = mat
	head.position = Vector3(0, 1.6, -0.1)
	rig.add_child(head)

	club_pivot = Node3D.new()
	club_pivot.position = Vector3(1.0, 0.5, -0.3)
	rig.add_child(club_pivot)
	var club := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.4, 0.4, 2.8)
	club.mesh = bm
	club.position = Vector3(0, 0, -1.4)
	var club_mat := StandardMaterial3D.new()
	club_mat.albedo_color = Color(0.1, 0.09, 0.09)
	club_mat.roughness = 1.0
	club.material_override = club_mat
	club_pivot.add_child(club)
	club_pivot.rotation.x = 0.3


func _forward() -> Vector3:
	return Vector3(-sin(model.rotation.y), 0.0, -cos(model.rotation.y))


func _face(dir: Vector3, weight: float) -> void:
	if dir.length() > 0.01:
		model.rotation.y = lerp_angle(model.rotation.y, atan2(-dir.x, -dir.z), clampf(weight, 0.0, 1.0))


func _hit(dmg: float) -> void:
	player.take_damage(dmg, global_position)


func _start_attack(dist: float) -> void:
	var s := 0.8 if is_enraged else 1.0
	if dist > 5.5:
		attack = "lunge"
		windup = 0.7 * s
		strike = 0.35
		recover = 0.9 * s
	else:
		attack = ["slash", "slash", "slam"].pick_random()
		if attack == "slash":
			windup = 0.75 * s
			strike = 0.2
			recover = 0.7 * s
		else:
			windup = 1.1 * s
			strike = 0.2
			recover = 1.0 * s
	state = "windup"
	state_time = 0.0
	hit_done = false


func _physics_process(delta: float) -> void:
	if state == "dead":
		velocity.x = 0.0
		velocity.z = 0.0
		velocity.y -= GRAVITY * delta
		move_and_slide()
		return
	if player == null:
		player = get_tree().get_first_node_in_group("player")
		if player == null:
			return

	state_time += delta
	var to: Vector3 = player.global_position - global_position
	to.y = 0.0
	var dist := to.length()
	var dir := to.normalized() if dist > 0.01 else Vector3.ZERO
	var player_alive: bool = player.state != "dead"
	var glow := 0.0

	match state:
		"chase":
			_face(dir, 5.0 * delta)
			if dist > 2.8 and player_alive:
				velocity.x = dir.x * speed
				velocity.z = dir.z * speed
			else:
				velocity.x = 0.0
				velocity.z = 0.0
			cooldown -= delta
			if cooldown <= 0.0 and player_alive:
				_start_attack(dist)
		"windup":
			_face(dir, 2.0 * delta)
			velocity.x = 0.0
			velocity.z = 0.0
			var k := clampf(state_time / windup, 0.0, 1.0)
			glow = k * 2.5
			club_pivot.rotation.x = lerpf(0.3, 1.8, k)
			if state_time >= windup:
				state = "strike"
				state_time = 0.0
				hit_done = false
		"strike":
			var k := clampf(state_time / strike, 0.0, 1.0)
			club_pivot.rotation.x = lerpf(1.8, -1.0, k)
			velocity.x = 0.0
			velocity.z = 0.0
			match attack:
				"slash":
					if not hit_done:
						hit_done = true
						if dist < 4.0 and _forward().dot(dir) > 0.2:
							_hit(20.0)
				"slam":
					if not hit_done:
						hit_done = true
						if dist < 4.6:
							_hit(32.0)
				"lunge":
					var f := _forward()
					velocity.x = f.x * 14.0
					velocity.z = f.z * 14.0
					if not hit_done and dist < 2.5:
						hit_done = true
						_hit(26.0)
			if state_time >= strike:
				state = "recover"
				state_time = 0.0
		"recover":
			velocity.x = 0.0
			velocity.z = 0.0
			var k := clampf(state_time / recover, 0.0, 1.0)
			club_pivot.rotation.x = lerpf(-1.0, 0.3, k)
			if state_time >= recover:
				state = "chase"
				state_time = 0.0
				cooldown = randf_range(0.6, 1.4) * (0.7 if is_enraged else 1.0)

	velocity.y = -0.1 if is_on_floor() else velocity.y - GRAVITY * delta
	move_and_slide()

	if hurt_t > 0.0:
		hurt_t -= delta
		mat.emission = Color(1, 1, 1)
		mat.emission_energy_multiplier = 1.2
	else:
		mat.emission = Color(1, 0.15, 0.05)
		mat.emission_energy_multiplier = glow


func take_damage(amount: float, _from_pos: Vector3) -> void:
	if state == "dead":
		return
	health -= amount
	hurt_t = 0.12
	if health <= 0.0:
		health = 0.0
		state = "dead"
		remove_from_group("enemies")
		collision_layer = 0
		mat.emission_energy_multiplier = 0.0
		create_tween().tween_property(rig, "rotation:x", -PI / 2.0, 1.5)
		died.emit()
	elif not is_enraged and health < max_health * 0.5:
		is_enraged = true
		speed = 4.4
		mat.albedo_color = Color(0.4, 0.1, 0.08)
		enraged.emit()
