extends Control
# On-screen controls for phones. Left side = move stick, right side = buttons,
# drag anywhere else on the right to rotate the camera.

static var look_delta := Vector2.ZERO

const R_STICK := 100.0
var enabled := false
var stick_id := -1
var stick_origin := Vector2.ZERO
var stick_vec := Vector2.ZERO
var look_id := -1
var held := {}


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	enabled = OS.has_feature("mobile") or DisplayServer.is_touchscreen_available()
	set_process_input(enabled)
	set_process(enabled)


func _buttons() -> Dictionary:
	var w := size.x
	var h := size.y
	return {
		"dodge": [Vector2(w - 130, h - 110), 58.0, "ROLL"],
		"attack_light": [Vector2(w - 250, h - 170), 58.0, "ATK"],
		"attack_heavy": [Vector2(w - 130, h - 250), 58.0, "HEAVY"],
		"heal": [Vector2(w - 280, h - 60), 42.0, "HEAL"],
		"lock_on": [Vector2(w - 100, h - 390), 40.0, "LOCK"],
		"sprint": [Vector2(w - 380, h - 130), 42.0, "RUN"],
	}


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_on_press(event.index, event.position)
		else:
			_on_release(event.index)
	elif event is InputEventScreenDrag:
		_on_drag(event.index, event.position, event.relative)


func _on_press(index: int, pos: Vector2) -> void:
	var btns := _buttons()
	for name in btns:
		var b: Array = btns[name]
		if pos.distance_to(b[0]) <= float(b[1]) * 1.2:
			held[index] = name
			Input.action_press(name)
			return
	if pos.x < size.x * 0.45 and stick_id == -1:
		stick_id = index
		stick_origin = pos
		stick_vec = Vector2.ZERO
	elif look_id == -1:
		look_id = index


func _on_release(index: int) -> void:
	if held.has(index):
		Input.action_release(held[index])
		held.erase(index)
	elif index == stick_id:
		stick_id = -1
		stick_vec = Vector2.ZERO
		_apply_stick()
	elif index == look_id:
		look_id = -1


func _on_drag(index: int, pos: Vector2, relative: Vector2) -> void:
	if index == stick_id:
		stick_vec = (pos - stick_origin).limit_length(R_STICK) / R_STICK
		_apply_stick()
	elif index == look_id:
		look_delta += relative


func _apply_stick() -> void:
	_set_action("move_left", maxf(-stick_vec.x, 0.0))
	_set_action("move_right", maxf(stick_vec.x, 0.0))
	_set_action("move_forward", maxf(-stick_vec.y, 0.0))
	_set_action("move_back", maxf(stick_vec.y, 0.0))


func _set_action(action: String, strength: float) -> void:
	if strength > 0.15:
		Input.action_press(action, strength)
	else:
		Input.action_release(action)


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	if not enabled:
		return
	var base := stick_origin if stick_id != -1 else Vector2(190, size.y - 170)
	draw_circle(base, R_STICK, Color(1, 1, 1, 0.1))
	draw_circle(base + stick_vec * R_STICK, 40.0, Color(1, 1, 1, 0.3))
	var btns := _buttons()
	var font := ThemeDB.fallback_font
	for name in btns:
		var b: Array = btns[name]
		var pressed := Input.is_action_pressed(name)
		var c: Vector2 = b[0]
		var r: float = b[1]
		draw_circle(c, r, Color(1, 1, 1, 0.38 if pressed else 0.16))
		draw_arc(c, r, 0.0, TAU, 32, Color(1, 1, 1, 0.5), 2.0)
		draw_string(font, c + Vector2(-r, 7), b[2], HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 18)
